import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonButton, IonItem, IonInput, IonList, IonSelect, IonSelectOption, AlertController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gestion-carreras',
  templateUrl: './gestion-carreras.page.html',
  styleUrls: ['./gestion-carreras.page.scss'],
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule, IonButton, IonItem, IonInput, IonList, IonSelect, IonSelectOption]
})
export class GestionCarrerasPage {

  // Aquí se guardan los datos que el usuario escribe en el formulario
  carrera = {
    nombre: '',
    tipo: ''
  };

  constructor(private http: HttpClient, private router: Router, private alertController: AlertController) { }

  // Muestra una ventana con un mensaje
  async mostrarAlerta(mensaje: string) {
    const alert = await this.alertController.create({
      header: 'Aviso',
      message: mensaje,
      buttons: ['OK']
    });
    await alert.present();
  }

  // Se ejecuta al presionar el botón "Guardar"
  async guardarDatos() {

    // 1. Revisar que no haya campos vacíos
    let hayVacios = false;

    if (this.carrera.nombre.trim() === '') {
      hayVacios = true;
    }
    if (!this.carrera.tipo) {
      hayVacios = true;
    }

    if (hayVacios) {
      await this.mostrarAlerta('Por favor, llena todos los campos');
      return; // Se detiene aquí y no se envía nada al servidor
    }

    // 2. Enviar los datos al PHP
    const urlAPI = "http://192.168.137.1/api_ionic/gestion-carreras.php";

    this.http.post(urlAPI, this.carrera).subscribe({

      // Si el servidor respondió
      next: async (respuesta: any) => {
        console.log('respuesta del servidor', respuesta);

        if (respuesta.status === 'success') {
          await this.mostrarAlerta(respuesta.mensaje);
          this.router.navigate(['/home']);
        } else if (respuesta.status === 'error') {
          await this.mostrarAlerta(respuesta.mensaje);
        }
      },

      // Si no se pudo conectar con el servidor
      error: async (error) => {
        console.log('Error de conexion', error);
        await this.mostrarAlerta('Error de conexion con el servidor');
      }
    });
  }

}
