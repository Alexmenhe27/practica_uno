import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonButton, IonButtons, IonItem, IonInput, IonList, AlertController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, CommonModule,
     FormsModule, IonButton, IonButtons, IonItem, IonInput, IonList]
})
export class RegistroPage implements OnInit {
  usuario={
    nombre:'', matricula:'', correo:''};

  constructor(private http: HttpClient, private router: Router, private alertController: AlertController) { }

  ngOnInit() {
  }

  async mostrarAlerta(mensaje: string){
    const alert = await this.alertController.create({
      header: 'Aviso',
      message: mensaje,
      buttons: ['OK']
    });
    await alert.present();
  }

  async guardarDatos(){
   // Validar que no vengan vacíos
   if (!this.usuario.nombre.trim() || !this.usuario.matricula.trim() || !this.usuario.correo.trim()) {
     await this.mostrarAlerta('Por favor, llena todos los campos');
     return; // Detiene la función y no envía la petición
   }
   const urlAPI = "http://192.168.137.1/api_ionic/registro.php";
   this.http.post(urlAPI, this.usuario).subscribe({
     next: async (respuesta:any)=>{
       console.log('respuesta del servidor', respuesta);
       if(respuesta.status === 'success'){
         this.router.navigate(['/home']);
       } else if(respuesta.status === 'error'){
         await this.mostrarAlerta(respuesta.mensaje);
       }
     },
     error: async (error)=>{
       console.log('Error de conexion', error);
       await this.mostrarAlerta('Error de conexion con el servidor');
     }
   })
 }
}